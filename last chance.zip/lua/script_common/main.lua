print('script_common:hello world')
Entity.addValueDef("time", 0, true, true, true)